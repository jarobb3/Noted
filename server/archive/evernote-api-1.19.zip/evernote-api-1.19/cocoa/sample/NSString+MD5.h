//
//  NSString+MD5.h
//  Copyright 2011 Evernote Corporation. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface NSString (MD5)

- (NSData *) md5;

@end
