//
//  SecondViewController.h
//  client
//
//  Evernote API sample code is provided under the terms specified in the file LICENSE.txt which was included with this distribution.
//

#import <UIKit/UIKit.h>


@interface NotesListViewController : UITableViewController {
    
    NSMutableArray *listOfItems;
    NSMutableArray *indexArray;
}

@end
