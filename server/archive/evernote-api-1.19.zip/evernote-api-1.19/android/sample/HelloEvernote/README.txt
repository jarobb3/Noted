This directory contains an Android project for Eclipse that demonstrates how to use 
Intents to interact with the Evernote for Android application. To open the project in
Eclipse, choose File->Import, expand the General folder, and select Existing Projects
into Workspace. Choose the HelloEvernote directory and click Finish.

You can find documentation of the Intents supported by Evernote for Android at 
http://www.evernote.com/about/developer/android.php

To download Evernote for Android, visit the Android Market:
https://market.android.com/details?id=com.evernote

The Evernote for Developers forum can be found at
http://forum.evernote.com/phpbb/viewforum.php?f=43

The Evernote for Android forum can be found at
http://forum.evernote.com/phpbb/viewforum.php?f=51 